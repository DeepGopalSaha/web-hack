from flask import Flask, request, render_template, jsonify, send_from_directory
import base64
import os
import random
from datetime import datetime

app = Flask(__name__)

UPLOAD_FOLDER = 'uploads/'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

CARTOON_DIR = 'cartoon/'

@app.route('/')
def index():
    print("Server started")
    return render_template('index.html')

@app.route('/upload-image', methods=['POST'])
def upload_image():
    try:
        data = request.get_json()
        
        # Get the image data
        image_data = data['image'].split(",")[1]  # Get the base64 encoded string
        image_data = base64.b64decode(image_data)  # Decode the string
        
        # Generate a timestamp for the image filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        file_path = os.path.join(UPLOAD_FOLDER, f'image_{timestamp}.png')
        
        # Save the image
        with open(file_path, 'wb') as f:
            f.write(image_data)
        
        print("Image received and saved successfully")
        return 'Saved'
    
    except Exception as e:
        print(f"Error: {e}")
        return "Error saving image, internal server error", 500

@app.route('/upload-location', methods=['POST'])
def upload_location():
    data = request.get_json()
    location = data['location']

    # Save or print location data
    print(f'Received location: {location}')
    return 'Location successfully uploaded!'

@app.route('/get-random-cartoon')
def get_random_cartoon():
    cartoon_images = os.listdir(CARTOON_DIR)
    random_cartoon = random.choice(cartoon_images)
    return jsonify({'imageUrl': f'/cartoon-images/{random_cartoon}'})

@app.route('/cartoon-images/<filename>')
def serve_cartoon_image(filename):
    return send_from_directory(CARTOON_DIR, filename)

if __name__ == '__main__':
    app.run(port=2525)
